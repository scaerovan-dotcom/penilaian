# PMR WIRA UNIT — Online Quest

## Setup singkat
1. Buat Firebase project.
2. Aktifkan Authentication:
   - Anonymous untuk peserta.
   - Email/Password untuk admin.
3. Buat Firestore Database.
4. Tempel `firestore.rules` ke Firestore Rules.
5. Buka `index.html`, cari `const firebaseConfig` dan ganti placeholder dengan konfigurasi Web App Firebase.
6. Buat akun admin di Firebase Authentication > Users.
7. Upload `index.html` ke repository GitHub sebagai `index.html`.
8. Aktifkan GitHub Pages dari branch `main`, folder `/root`.

## Admin
Tidak ada PIN di source code. Admin masuk menggunakan Email + Password Firebase.

## Catatan keamanan
Rules ini melindungi akses dokumen berdasarkan UID. Untuk kompetisi resmi/anti-cheat, skor sebaiknya dihitung di backend/Cloud Functions karena JavaScript di browser tetap dapat dimodifikasi pengguna.
